package com.test.projetfinal.fragments;

public class Response {
    private String text;
    private boolean isSelected;

    public Response(String text, boolean b) {
        this.text = text;
        this.isSelected = false;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}
