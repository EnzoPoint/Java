package com.test.projetfinal.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.test.projetfinal.R;

import java.util.ArrayList;
import java.util.Map;

public class SendFragment extends Fragment {

    private Button sendButton;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_send, container, false);

        // Get views from the layout
        sendButton = rootView.findViewById(R.id.send_button);

        // Set click listener for send button
        sendButton.setOnClickListener(view -> {
            //String message = messageTextView.getText().toString();
            //String contact = contactSpinner.getSelectedItem().toString();

            ArrayList<String> contacts = getContacts();
            String message = getResponses();

            // Send message to selected contacts
            sendMessageToContacts(message, contacts);

            // Show toast message
            showToast("Message sent");
        });

        return rootView;
    }

    private void sendMessageToContacts(String message, ArrayList<String> contacts) {
        // TODO: Implement logic to send message to selected contacts
        // Use SmsManager class to send SMS messages

        System.out.println("Message: " + message);
        System.out.println("Contact: " + contacts);

        // Toast alert
        if (message == null)
            showToast("Message is null");

        // Example code to send message using SmsManager
        SmsManager smsManager = SmsManager.getDefault();

        for (String contact : contacts) {
            smsManager.sendTextMessage(contact, null, message, null, null);
        }
        //smsManager.sendTextMessage(contact, null, message, null, null);
    }

    private void showToast(String message) {
        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
    }

    private String getResponses() {
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("responses", Context.MODE_PRIVATE);
        Map<String, Boolean> responses = (Map<String, Boolean>) sharedPreferences.getAll();
        for (Map.Entry<String, Boolean> entry : responses.entrySet()) {
            if (entry.getValue()) {
                return entry.getKey();
            }
        }

        return null;
    }

    private ArrayList<String> getContacts() {
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("contacts", Context.MODE_PRIVATE);
        Map<String, Boolean> contacts = (Map<String, Boolean>) sharedPreferences.getAll();
        ArrayList<String> contactsList = new ArrayList<>();
        for (Map.Entry<String, Boolean> entry : contacts.entrySet()) {
            if (entry.getValue()) {
                contactsList.add(entry.getKey());
            }
        }

        return contactsList;
    }
}
