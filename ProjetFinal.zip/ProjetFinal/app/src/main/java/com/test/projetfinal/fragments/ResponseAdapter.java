package com.test.projetfinal.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.TextView;
import com.test.projetfinal.R;

import java.util.List;

public class ResponseAdapter extends ArrayAdapter<Response> {

    private Context context;
    private int resource;
    private List<Response> responseList;

    public ResponseAdapter(Context context, int resource, List<Response> responseList) {
        super(context, resource, responseList);
        this.context = context;
        this.resource = resource;
        this.responseList = responseList;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = LayoutInflater.from(context).inflate(resource, null);
        Response response = responseList.get(position);

        if (response != null) {
            TextView responseText = view.findViewById(R.id.response_text);
            RadioButton responseSelected = view.findViewById(R.id.response_selected);
            ImageButton deleteButton = view.findViewById(R.id.response_delete_button);

            responseText.setText(response.getText());

            responseSelected.setChecked(response.isSelected());

            deleteButton.setOnClickListener((buttonView) -> {
                responseList.remove(position);
                notifyDataSetChanged();
            });

            responseSelected.setOnClickListener((buttonView) -> {
                boolean isChecked2 = responseSelected.isChecked();
                // Met à jour l'état de la réponse sélectionnée
                response.setSelected(isChecked2);

                // Désélectionne les autres réponses
                for (Response r : responseList) {
                    //Log.d("salut", "getView: " + r.getText() + " " + response.getText());
                    if (!r.getText().equals(response.getText())) {
                        saveSelectedButtonState(r.getText(), context, false);
                    } else {
                        saveSelectedButtonState(r.getText(), context, true);
                    }
                }

                // Notifie l'adapter que les données ont changé
                notifyDataSetChanged();
            });

            // Récupère l'état précédent du bouton et le restaure si nécessaire
            boolean isChecked = getCheckBoxState(response.getText(), context);
            responseSelected.setChecked(isChecked);
            response.setSelected(isChecked);
        }

        return view;
    }

    private void saveSelectedButtonState(String responseText, Context context, boolean isChecked) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("responses", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(responseText, isChecked);
        editor.apply();
    }

    private boolean getCheckBoxState(String responseText, Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("responses", Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean(responseText, false);
    }
}
