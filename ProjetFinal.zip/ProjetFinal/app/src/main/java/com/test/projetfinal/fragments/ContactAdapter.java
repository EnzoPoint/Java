package com.test.projetfinal.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.test.projetfinal.R;

import java.util.List;

public class ContactAdapter extends RecyclerView.Adapter<ContactViewHolder> {
    private List<Contact> contacts;
    private Context context;

    public ContactAdapter(List<Contact> contacts, Context context) {
        this.contacts = contacts;
        this.context = context;
    }
    @NonNull
    @Override
    public ContactViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.contact_item, parent, false);
        return new ContactViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull ContactViewHolder holder, int position) {
        Contact contact = contacts.get(position);
        holder.bind(contact, context);
    }

    /**
     * Returns the total number of items in the data set held by the adapter.
     *
     * @return The total number of items in this adapter.
     */
    @Override
    public int getItemCount() {
        return contacts.size();
    }
}

class ContactViewHolder extends RecyclerView.ViewHolder {
    private TextView numberTextView;
    private CheckBox checkBox;
    private TextView nameTextView;

    public ContactViewHolder(@NonNull View itemView) {
        super(itemView);
        numberTextView = itemView.findViewById(R.id.contact_number);
        nameTextView = itemView.findViewById(R.id.contact_name);
        checkBox = itemView.findViewById(R.id.contact_checkbox);
    }

    public void bind(Contact item, Context context) {
        nameTextView.setText(item.getName());
        numberTextView.setText(item.getNumber());
        checkBox.setChecked(getCheckBoxState(item.getNumber(), context));

        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Sauvegarde l'état de la case à cocher dans les préférences partagées
                saveCheckBoxState(item.getNumber(), context, isChecked);
            }
        });
    }

    private void saveCheckBoxState(String contactId, Context context, boolean isChecked) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("contacts", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(String.valueOf(contactId), isChecked);
        editor.apply();
    }

    private Boolean getCheckBoxState(String contactId, Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("contacts", Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean(String.valueOf(contactId), false);
    }
}