package com.test.projetfinal;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

/// Import des fragments ///

import com.test.projetfinal.fragments.ResponseFragment;
import com.test.projetfinal.fragments.ContactsFragment;
import com.test.projetfinal.fragments.SendFragment;

import java.util.ArrayList;

public class PagerAdapter extends FragmentPagerAdapter {

    private final ArrayList<Page> Pages = new ArrayList<>();

    public PagerAdapter(@NonNull FragmentManager fm, int behavior, Context context) {
        super(fm, behavior);

        // Ajout du premier fragment à la liste de pages
        Pages.add(new Page("Mes contacts", new ContactsFragment()));
        Pages.add(new Page("Mes réponses", new ResponseFragment()));
        Pages.add(new Page("Envoie", new SendFragment()));

    }

    // Retourne le fragment à l'index donné
    @NonNull
    @Override
    public Fragment getItem(int position) {
        return Pages.get(position).getFragment();
    }

    // Retourne le nombre total de pages
    @Override
    public int getCount() {
        return Pages.size();
    }

    // Retourne le titre de la page à l'index donné
    @Override
    public CharSequence getPageTitle(int position) {
        return Pages.get(position).getTitle();
    }

    // Classe interne représentant une page
    private static class Page {
        private final String Title;
        private final Fragment Fragment;

        public Page(String title, Fragment fragment) {
            Title = title;
            Fragment = fragment;
        }

        public String getTitle() {
            return Title;
        }

        public Fragment getFragment() {
            return Fragment;
        }
    }
}
