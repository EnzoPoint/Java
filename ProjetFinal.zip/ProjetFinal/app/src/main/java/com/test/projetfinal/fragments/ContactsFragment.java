package com.test.projetfinal.fragments;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.test.projetfinal.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class ContactsFragment extends Fragment {

    private RecyclerView recyclerView;
    private ContactAdapter cursorAdapter;
    public static final int REQUEST_CODE_READ_CONTACTS = 79; // une valeur quelconque pour le code de demande d'autorisation

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate le layout fragment_contacts.xml
        View view = inflater.inflate(R.layout.fragment_contacts, container, false);

        // Récupère la ListView depuis le layout
        recyclerView = view.findViewById(R.id.contacts_list_view);

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        // Check for READ_CONTACTS, SEND_SMS, READ_SMS permissions
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        && ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
        && ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
            displayContacts();
        } else {
            ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS}, REQUEST_CODE_READ_CONTACTS);
        }
    }

    private List<Contact> getContacts() {
        // Vérifier si l'autorisation de lire les contacts a été accordée
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            // Demander l'autorisation si elle n'a pas été accordée
            ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.READ_CONTACTS}, REQUEST_CODE_READ_CONTACTS);
            return null; // retourner null si l'autorisation n'a pas été accordée
        }
        // Récupérer le curseur contenant les contacts
        Cursor cursor = requireActivity().getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);
        // Créer un tableau pour stocker les informations des contacts
        List<Contact> contacts = new ArrayList<>();
        // Parcourir les résultats du curseur et stocker les informations des contacts dans le tableau

        while (cursor.moveToNext()) {
            @SuppressLint("Range")
            String name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
            @SuppressLint("Range")
            String id = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone._ID));
            @SuppressLint("Range")
            String phoneNumber = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
            contacts.add(new Contact(name, phoneNumber, id));
        }
        // Fermer le curseur
        cursor.close();
        // Retourner le tableau
        return contacts.stream().filter(distinctByKey(Contact::getNumber)).collect(Collectors.toList());
    }

    private static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Map<Object, Boolean> seen = new ConcurrentHashMap<>();
        return t -> seen.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }

    private void displayContacts() {
        cursorAdapter = new ContactAdapter(getContacts(), requireContext());

        recyclerView.setAdapter(cursorAdapter);

        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));

        cursorAdapter.notifyDataSetChanged();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                displayContacts();
            } else {
                Toast.makeText(requireContext(), "Permission refusée. Veuillez accorder l'autorisation d'accéder aux contacts dans Paramètres", Toast.LENGTH_LONG).show();
            }
        }
    }
}









