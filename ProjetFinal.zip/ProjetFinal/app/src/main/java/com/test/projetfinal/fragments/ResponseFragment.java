package com.test.projetfinal.fragments;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.test.projetfinal.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ResponseFragment extends Fragment {

    private ListView responseListView;
    private ResponseAdapter responseAdapter;
    private List<Response> responseList;
    private Button addButton;
    private ImageButton suppButton;
    private EditText newResponseText;

    public ResponseFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_response, container, false);

        responseListView = view.findViewById(R.id.response_list);
        addButton = view.findViewById(R.id.response_add_button);
        newResponseText = view.findViewById(R.id.response_add_text);

        // Initialise la liste de réponses possibles
        responseList = loadResponses();
        responseList.add(new Response("Oui", false));
        responseList.add(new Response("Non", false));
        responseList.add(new Response("Peut-être", false));
        responseList.add(new Response("Je ne sais pas", false));

        responseAdapter = new ResponseAdapter(getActivity(), R.layout.response_item, responseList);
        responseListView.setAdapter(responseAdapter);

        addButton.setOnClickListener((View v) -> {
            String newResponse = newResponseText.getText().toString().trim();

            if (!newResponse.isEmpty()) {
                Response response = new Response(newResponse, false);
                responseList.add(response);
                responseAdapter.notifyDataSetChanged();
                saveResponse(response.getText(), false);
                newResponseText.getText().clear();
            }
        });

        return view;
    }

    @Override
    public void onPause() {
        super.onPause();

        // Save selected state of responses to SharedPreferences
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("responses", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        for (Response response : responseList) {
            editor.putBoolean(response.getText(), response.isSelected());
        }

        editor.apply();
    }

    private void saveResponse(String responseText, boolean isSelected) {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("responses", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(responseText, isSelected);
        editor.apply();
    }

    private List<Response> loadResponses() {
        List<Response> responses = new ArrayList<>();

        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("responses", Context.MODE_PRIVATE);
        Map<String, ?> responseMap = sharedPreferences.getAll();

        for (Map.Entry<String, ?> entry : responseMap.entrySet()) {
            String text = entry.getKey();
            boolean selected = (Boolean) entry.getValue();
            responses.add(new Response(text, selected));
        }

        return responses;
    }
}
